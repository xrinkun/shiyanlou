#!/bin/bash
df -h | awk 'NR==2{b=$5;if($5<"85%"){a="is OK"}else{a="need notice"}{printf "Disk-Root:\t%s",a;printf ",use: %s\n",b}}'
free | awk 'NR==2{d=$3/$2;if(d < 0.9){c="is OK"}else{c="need notice"}{printf "Memory:         %s",c;printf ",use: %s%%\n",d*100}}'
e=$( uptime | awk '{print $10}' | sed 's/,//' )
echo $e
if (( $e < "0.7" ));then
    echo"Loadaverage:    is OK,use: $e"
else:
    echo"Loadaverage:    need notice,use: $e"
fi
