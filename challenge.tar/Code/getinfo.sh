#!/bin/bash
df -h | awk 'NR==2{b=$5;if($5<"85%"){a="is OK"}else{a="need notice"}{printf "Disk-Root:\t%s",a;printf ",use:%s",b}}'
