#!/usr/bin/env python3
import sys
li = []
try:
    for arg in sys.argv[1:]:
        li.extend(arg.split(':'))
    li = [int(x) for x in li]
except:
    print("Parameter Error")
    sys.exit(0)
def bao(n):
    r=0.00
    float(r)
    if n <= 3500:
        r = format(n-n*0.165, ".2f")
    elif n <= 5000:
        r = format(n-(n-n*0.165-3500) * 0.03- n*0.165, ".2f")
    elif n <= 8000:
        r = format(n-(n-n*0.165-3500) * 0.1 - 105 - n*0.165, ".2f")
    elif n <= 12500:
        r = format(n-(n-n*0.165-3500) * 0.2 - 555 - n*0.165, ".2f")
    elif n <= 38500:
        r = format(n-(n-n*0.165-3500) * 0.25 - 1005 - n*0.165, ".2f")
    elif n <= 58500:
        r = format(n-(n-n*0.165-3500) * 0.3 - 2755 - n*0.165, ".2f")
    elif n <= 83500:
        r = format(n-(n-n*0.165-3500) * 0.35 - 5505 - n*0.165, ".2f")
    else:
        r = format(n-(n-n*0.165-3500) * 0.35 - 13505 - n*0.165, ".2f")
    return r
for k in range(len(li)):
    if k%2 != 0:
        li[k] = float(bao(li[k]))
for i in range(len(li)):
    if i%2 == 0 and i+1 != len(li):
        print("%d:%.2f" % (li[i],li[i+1]))
